function askBrando(question) {
    return "Resposta simulada da Brando API para: " + question;
}
function infoBrando() {
    return {status: "online", version: "1.0.0", name: "Brando API"};
}